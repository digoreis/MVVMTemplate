//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Foundation

class ___FILEBASENAME___ViewModel: ___FILEBASENAME___DataSource, ___FILEBASENAME___Delegate {
    
    // MARK: - Attributes
    
    var feedback: ___FILEBASENAME___Feedback?
    
    // MARK: - View Lifecycle
    
    // MARK: - Instance Methods
    
    // MARK: - ___FILEBASENAME___Delegate Methods
    
    // MARK: - ___FILEBASENAME___DataSource Methods
}